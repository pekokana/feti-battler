import flet as ft
import hashlib
import base64
import asyncio
import random

async def main(page: ft.Page):
    page.title = "FETI-BATTLER: Duel"
    page.theme_mode = ft.ThemeMode.DARK
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.AUTO

    players = [
        {"data": None, "ui": None},
        {"data": None, "ui": None}
    ]

    battle_log = ft.Column(spacing=5)
    
    battle_button = ft.FilledButton(
        "BATTLE START!", 
        visible=False, 
        width=200, 
        height=50,
        style=ft.ButtonStyle(color=ft.Colors.WHITE, bgcolor=ft.Colors.RED)
    )

    def analyze_image(img_bytes):
        seed = hashlib.sha256(img_bytes).hexdigest()
        hp = int(seed[0:4], 16) % 5000 + 3000
        atk = int(seed[4:8], 16) % 1000 + 500
        spd = int(seed[8:12], 16) % 100 + 10
        
        material_val = int(seed[10:13], 16) % 255
        if material_val < 50:
            m, col = "漆黒 of ラバー", ft.Colors.AMBER_ACCENT_200
        elif material_val < 110:
            m, col = "至高 of スキン", ft.Colors.ORANGE_200
        elif material_val < 170:
            m, col = "伝統 of スク水 / 制服", ft.Colors.BLUE_800
        elif material_val < 230:
            m, col = "聖なるシルク / ナース", ft.Colors.WHITE
        else:
            m, col = "未知の魔導素材", ft.Colors.GREY_400
        
        return {"hp": hp, "max_hp": hp, "atk": atk, "spd": spd, "material": m, "color": col}

    async def run_battle(e):
        battle_button.disabled = True
        battle_log.controls.clear()
        p1, p2 = players[0]["data"], players[1]["data"]
        p1["hp"], p2["hp"] = p1["max_hp"], p2["max_hp"]
        
        log_add("── BATTLE START ──", ft.Colors.YELLOW)
        
        while p1["hp"] > 0 and p2["hp"] > 0:
            if p1["spd"] + random.randint(0,20) >= p2["spd"] + random.randint(0,20):
                turn = [p1, p2]
            else:
                turn = [p2, p1]

            for attacker in turn:
                defender = p2 if attacker == p1 else p1
                if attacker["hp"] <= 0: continue
                dmg = int(attacker["atk"] * random.uniform(0.9, 1.2))
                defender["hp"] -= dmg
                offence = "Player 1" if attacker == p1 else "Player 2"
                log_add(f"{offence}:{attacker['material']} の攻撃！ {dmg} ダメージ！", attacker["color"])
                await asyncio.sleep(0.4)
                page.update()
                if defender["hp"] <= 0:
                    log_add(f"── {attacker['material']} WIN! ──", ft.Colors.RED_ACCENT)
                    break
        
        battle_button.disabled = False
        page.update()

    def log_add(text, color):
        battle_log.controls.insert(0, ft.Text(text, color=color, weight="bold"))
        page.update()

    # コアとなる画像選択ロジック
    async def handle_pick(idx):
        # picker = ft.FilePicker()
        # page.overlay.append(picker)
        # page.update()
        
        # ファイルピッカーを起動（Web版対応のためwith_data=True）
        files = await ft.FilePicker().pick_files(
            file_type=ft.FilePickerFileType.IMAGE,
            allow_multiple=False,
            with_data=True
        )

        if not files or not files[0].bytes:
            # page.overlay.remove(picker)
            page.update()
            return

        img_bytes = files[0].bytes
        res = analyze_image(img_bytes)
        players[idx]["data"] = res
        
        img_base64 = base64.b64encode(img_bytes).decode()
        players[idx]["ui"].content.controls[1].src = f"data:image/png;base64,{img_base64}"
        players[idx]["ui"].content.controls[2].value = res["material"]
        players[idx]["ui"].content.controls[2].color = res["color"]
        players[idx]["ui"].content.controls[3].value = f"HP:{res['hp']} ATK:{res['atk']} SPD:{res['spd']}"
        players[idx]["ui"].visible = True
        
        if players[0]["data"] and players[1]["data"]:
            battle_button.visible = True
        
        page.update()

    # --- 重要：lambdaを使わず、awaitを明示した専用ハンドラを作成 ---
    async def pick_player_1(e):
        await handle_pick(0)

    async def pick_player_2(e):
        await handle_pick(1)

    def create_card(idx):
        return ft.Container(
            visible=False,
            padding=10,
            border=ft.Border.all(1, ft.Colors.WHITE24),
            border_radius=10,
            content=ft.Column([
                ft.Text(f"UNIT {idx+1}", size=12, color="grey"),
                ft.Image(src="", width=140, height=140, fit="cover", border_radius=5),
                ft.Text("", size=16, weight="bold"),
                ft.Text("", size=12),
            ], horizontal_alignment="center")
        )

    players[0]["ui"] = create_card(0)
    players[1]["ui"] = create_card(1)
    battle_button.on_click = run_battle

    page.add(
        ft.Text("FETI-BATTLER: DUEL", size=32, weight="black"),
        ft.Row([
            ft.Column([
                # lambdaではなく、定義したasync関数を直接渡す
                ft.FilledButton("UNIT 1 選択", on_click=pick_player_1),
                players[0]["ui"]
            ], horizontal_alignment="center"),
            ft.Text("VS", size=20, weight="bold"),
            ft.Column([
                # lambdaではなく、定義したasync関数を直接渡す
                ft.FilledButton("UNIT 2 選択", on_click=pick_player_2),
                players[1]["ui"]
            ], horizontal_alignment="center"),
        ], alignment="center", spacing=20),
        ft.Divider(height=30, color="transparent"),
        battle_button,
        ft.Container(
            content=battle_log,
            height=200,
            width=400,
            bgcolor="black",
            padding=10,
            border_radius=5
        )
    )

if __name__ == "__main__":
    ft.run(main)