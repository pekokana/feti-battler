import flet as ft
import hashlib
import base64
import asyncio
import random

async def main(page: ft.Page):
    page.title = "フェチバトル: デュエル"
    page.theme_mode = ft.ThemeMode.DARK
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.AUTO

    page.fonts = {
        "Digital": "https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap",
        "Dot": "https://fonts.googleapis.com/css2?family=Silkscreen&display=swap"
    }

    players = [
        {"data": None, "ui": None},
        {"data": None, "ui": None}
    ]

    battle_log = ft.Column(spacing=5)
    
    battle_button = ft.FilledButton(
        "BATTLE START!", 
        visible=False, 
        width=200, 
        height=50,
        style=ft.ButtonStyle(color=ft.Colors.WHITE, bgcolor=ft.Colors.RED)
    )

    # --- ロジック層 ---

    def get_stats_from_seed(seed):
        """シード値（HEX文字列）からステータスを確定的に生成"""
        hp = int(seed[0:4], 16) % 5000 + 3000
        atk = int(seed[4:8], 16) % 1000 + 500
        def_val = int(seed[12:16], 16) % 300 + 100
        spd = int(seed[8:12], 16) % 100 + 10
        luk = int(seed[16:20], 16) % 20 + 5
        
        material_val = int(seed[10:13], 16) % 255
        if material_val < 50:
            m, col = "漆黒 of ラバー", ft.Colors.AMBER_ACCENT_200
        elif material_val < 110:
            m, col = "至高 of スキン", ft.Colors.ORANGE_200
        elif material_val < 170:
            m, col = "伝統 of スク水 / 制服", ft.Colors.BLUE_800
        elif material_val < 230:
            m, col = "聖なるシルク / ナース", ft.Colors.WHITE
        else:
            m, col = "未知の魔導素材", ft.Colors.GREY_400
        
        return {
            "hp": hp, "max_hp": hp, "atk": atk, "def": def_val, 
            "spd": spd, "luk": luk, "material": m, "color": col, 
            "seed": seed[:20] # 通信用の短いシード
        }

    def generate_identicon(seed_str, color):
        """シード値から9x9の対称形アイコンを生成"""
        # グローバルな random ではなく、この関数専用のランダム生成器を作る
        local_random = random.Random(seed_str)
        
        cells = []
        for y in range(9):
            # 1行の左側5マスをランダムに決定
            row_half = [random.choice([True, False]) for _ in range(5)]
            # 右側4マスを鏡合わせにする (0,1,2,3,4,3,2,1,0)
            row_full = row_half + row_half[-2::-1]
            cells.extend(row_full)

        return ft.Container(
            content=ft.GridView(
                runs_count=9,
                max_extent=14, # 140px / 9マス ≒ 15px
                spacing=1,
                run_spacing=1,
                controls=[
                    ft.Container(
                        bgcolor=color if is_on else ft.Colors.BLACK,
                        border_radius=1
                    ) for is_on in cells
                ],
            ),
            width=140,
            height=140,
            padding=5,
            bgcolor="black",
            border_radius=5,
            border=ft.Border.all(1, ft.Colors.WHITE10)
        )



    def update_stat_display(ui_container, data):
        # 新しい構造では controls[5] が stat_row
        stat_row = ui_container.content.controls[5]
        stat_row.controls[0].content.controls[1].value = str(data["hp"])
        stat_row.controls[1].content.controls[1].value = str(data["atk"])
        stat_row.controls[2].content.controls[1].value = str(data["def"])
        stat_row.controls[3].content.controls[1].value = str(data["spd"])
        stat_row.controls[4].content.controls[1].value = str(data["luk"])

    async def log_add_animated(text, color):
        new_log = ft.Text("", color=color, weight="bold", font_family="Digital")
        battle_log.controls.insert(0, new_log)
        display_text = ""
        for char in text:
            display_text += char
            new_log.value = display_text
            page.update()
            await asyncio.sleep(0.01)

    async def run_battle(e):
        battle_button.disabled = True
        battle_log.controls.clear()
        p1_data, p2_data = players[0]["data"], players[1]["data"]
        p1_ui, p2_ui = players[0]["ui"], players[1]["ui"]
        p1_data["hp"], p2_data["hp"] = p1_data["max_hp"], p2_data["max_hp"]
        
        update_stat_display(p1_ui, p1_data)
        update_stat_display(p2_ui, p2_data)
        await log_add_animated("── BATTLE START ──", ft.Colors.YELLOW)
        
        current_turn = 1
        while p1_data["hp"] > 0 and p2_data["hp"] > 0:
            turn_color = ft.Colors.CYAN_300 if current_turn % 2 == 1 else ft.Colors.ORANGE_200
            await log_add_animated(f"-- ターン {current_turn} --", turn_color)
            current_turn += 1

            if p1_data["spd"] + random.randint(0, 20) >= p2_data["spd"] + random.randint(0, 20):
                turn_order = [(p1_data, p2_data, p2_ui, "UNIT 1"), (p2_data, p1_data, p1_ui, "UNIT 2")]
            else:
                turn_order = [(p2_data, p1_data, p1_ui, "UNIT 2"), (p1_data, p2_data, p2_ui, "UNIT 1")]

            for attacker, defender, def_ui, attacker_name in turn_order:
                if attacker["hp"] <= 0 or defender["hp"] <= 0: continue

                base_dmg = int(attacker["atk"] * random.uniform(0.9, 1.2))
                dmg = max(1, base_dmg - defender["def"])
                log_msg, effect_color = f"{attacker_name}: 攻撃！", attacker["color"]

                if random.randint(1, 100) <= attacker["luk"]:
                    dmg, log_msg, effect_color = int(dmg * 1.5), f"{attacker_name}:★会心！", ft.Colors.ORANGE_600
                elif random.randint(1, 100) <= defender["luk"]:
                    dmg, log_msg, effect_color = max(1, int(dmg * 0.2)), f"{attacker_name}:★ガード！", ft.Colors.CYAN_300

                defender["hp"] -= dmg
                if defender["hp"] < 0: defender["hp"] = 0
                update_stat_display(def_ui, defender)
                await log_add_animated(f"{log_msg} {dmg} DMG", effect_color)

                def_ui.border = ft.Border.all(3, effect_color)
                await asyncio.sleep(0.3)
                def_ui.border = ft.Border.all(1, ft.Colors.WHITE24)
                page.update()

                if defender["hp"] <= 0:
                    await log_add_animated(f"── {attacker_name} WIN! ──", ft.Colors.RED_ACCENT)
                    break

        battle_button.disabled = False
        page.update()

    # --- インターフェース層 ---
    # async def handle_pick(idx):
    #     files = await ft.FilePicker().pick_files(file_type=ft.FilePickerFileType.IMAGE, with_data=True)
    #     if not files or not files[0].bytes: return
        
    #     seed = hashlib.sha256(files[0].bytes).hexdigest()
    #     res = get_stats_from_seed(seed)
    #     players[idx]["data"] = res
        
    #     img_base64 = base64.b64encode(files[0].bytes).decode()
    #     ui = players[idx]["ui"]
        
    #     # UI要素の取得
    #     target_image = ui.content.controls[1]
    #     target_title = ui.content.controls[2]
    #     target_text_button = ui.content.controls[4] # code_display

    #     # 画像とタイトルの更新
    #     target_image.src = f"data:image/png;base64,{img_base64}"
    #     target_title.value = res["material"]
    #     target_title.color = res["color"]

    #     # 【重要】ボタンの中のRowの中のTextを更新する
    #     # target_text_button(TextButton) -> content(Row) -> controls[0](Text)
    #     target_text_button.content.controls[0].value = f"CODE: {res['seed']}"
    #     target_text_button.content.controls[0].color = ft.Colors.WHITE
    #     target_text_button.content.controls[1].color = ft.Colors.WHITE
        
    #     update_stat_display(ui, res)
    #     ui.visible = True
    #     if players[0]["data"] and players[1]["data"]: 
    #         battle_button.visible = True
        
    #     page.update()

    async def handle_pick(idx):
        files = await ft.FilePicker().pick_files(file_type=ft.FilePickerFileType.IMAGE, with_data=True)
        if not files or not files[0].bytes: return
        
        seed = hashlib.sha256(files[0].bytes).hexdigest()
        res = get_stats_from_seed(seed)
        players[idx]["data"] = res
        
        img_base64 = base64.b64encode(files[0].bytes).decode()
        ui = players[idx]["ui"]
        
        # --- ここからパスを修正 ---
        # ui.content.controls (Column) の中身を順番に取得
        # 0: UNIT 1 (Text)
        # 1: load_header (Row)
        # 2: Divider
        # 3: Image
        # 4: WAITING... (Text)
        # 5: stat_row (Row)
        # 6: code_display (TextButton)
        
        target_image = ui.content.controls[3]
        target_title = ui.content.controls[4]
        target_text_button = ui.content.controls[6]

        target_image.src = f"data:image/png;base64,{img_base64}"
        target_image.opacity = 1.0 # 透過を解除
        target_title.value = res["material"]
        target_title.color = res["color"]

        # ボタンの中のRowの1番目(Text)を更新
        target_text_button.content.controls[0].value = f"CODE: {res['seed']}"
        target_text_button.content.controls[0].color = ft.Colors.WHITE
        target_text_button.content.controls[1].color = ft.Colors.WHITE
        
        update_stat_display(ui, res)
        if players[0]["data"] and players[1]["data"]: 
            battle_button.visible = True
        
        page.update()

    # async def load_by_code(idx, code_str):
    #     if len(code_str) < 20: return
    #     res = get_stats_from_seed(code_str)
    #     players[idx]["data"] = res
        
    #     ui = players[idx]["ui"]
    #     target_image = ui.content.controls[3]
    #     target_title = ui.content.controls[4]
    #     target_text_button = ui.content.controls[6]

    #     target_image.src = "https://flet.dev/img/pages/getting-started/icon.png"
    #     target_image.opacity = 0.8
    #     target_title.value = f"REMOTE: {res['material']}"
    #     target_title.color = res["color"]
        
    #     target_text_button.content.controls[0].value = f"CODE: {res['seed']}"
    #     target_text_button.content.controls[0].color = ft.Colors.WHITE
        
    #     update_stat_display(ui, res)
    #     if players[0]["data"] and players[1]["data"]: 
    #         battle_button.visible = True
    #     page.update()


    async def load_by_code(idx, code_str):
        if len(code_str) < 20: return
        res = get_stats_from_seed(code_str)
        players[idx]["data"] = res
        
        ui = players[idx]["ui"]
        new_icon = generate_identicon(res["seed"], res["color"])
        ui.content.controls[3] = new_icon


        target_title = ui.content.controls[4]
        target_text_button = ui.content.controls[6]

        target_title.value = f"{res['material']}"
        target_title.color = res["color"]
        
        target_text_button.content.controls[0].value = f"CODE: {res['seed']}"
        target_text_button.content.controls[0].color = ft.Colors.WHITE
        
        update_stat_display(ui, res)
        if players[0]["data"] and players[1]["data"]: 
            battle_button.visible = True
        page.update()


    def stat_panel(label, value, color):
        return ft.Container(
            content=ft.Column([
                ft.Text(label, size=10, color=color, font_family="Dot"),
                ft.Text(value, size=16, color=color, font_family="Digital"),
            ], spacing=0, horizontal_alignment="center"),
            bgcolor="black", padding=5, border_radius=5, width=62,
            border=ft.Border.all(1, ft.Colors.with_opacity(0.2, color))
        )

    async def copy_code(code_str):
        if code_str and "----" not in code_str:
            try:
                # サンプルサイトの方式：ft.Clipboard() インスタンスを作成して set する
                await ft.Clipboard().set(code_str)
                
                # ユーザーへのフィードバック
                page.snack_bar = ft.SnackBar(ft.Text(f"コードをコピーしました: {code_str}"))
                page.snack_bar.open = True
            except Exception as e:
                print(f"Clipboard Error: {e}")
                # 万が一上記でダメな場合、page.set_clipboard_data を試す古い習慣も残しておく
                # （バージョン混在対策）
            
            page.update()


    # def create_card(idx):
    #     stat_row = ft.Row([
    #         stat_panel("HP", "0", "greenaccent"),
    #         stat_panel("ATK", "0", "redaccent"),
    #         stat_panel("DEF", "0", "blueaccent"),
    #         stat_panel("SPD", "0", "amberaccent"),
    #         stat_panel("LUK", "0", "purpleaccent")
    #     ], spacing=4, alignment="center")

    #     code_input = ft.TextField(
    #         label="相手のコードを入力", width=160, height=30,
    #         text_size=10, on_submit=lambda e: load_by_code(idx, e.control.value)
    #     )

    #     # コピーボタンを兼ねたコード表示部
    #     code_display = ft.TextButton(
    #         content=ft.Row([
    #             ft.Text("CODE: ----", size=16, color="grey", font_family="Digital"), # controls[0]
    #             ft.Icon(ft.Icons.COPY, size=12, color="grey") # controls[1]
    #         ], alignment="center", spacing=5),
    #         # lambda内のパスを e.control.content.controls[0].value に修正
    #         on_click=lambda e: asyncio.create_task(
    #             copy_code(e.control.content.controls[0].value.replace("CODE: ", ""))
    #         )
    #     )

    #     return ft.Container(
    #         visible=False, padding=10, bgcolor=ft.Colors.GREY_900,
    #         border=ft.Border.all(1, ft.Colors.WHITE24), border_radius=10,
    #         content=ft.Column([
    #             ft.Text(f"UNIT {idx+1}", size=12, color="grey", font_family="Dot"),
    #             ft.Image(src="", width=140, height=140, fit="cover", border_radius=5),
    #             ft.Text("", size=16, weight="bold", font_family="Dot"),
    #             stat_row,
    #             code_display,
    #             code_input
    #         ], horizontal_alignment="center", spacing=10)
    #     )

    async def paste_and_load(idx, e):
        # クリップボードから取得
        code = await ft.Clipboard().get()
        if code:
            # 入力フィールドを探して値をセット（視覚的なフィードバック）
            # load_header -> controls[1] がTextField
            e.control.parent.controls[1].value = code
            page.update()
            # ロード実行
            await load_by_code(idx, code)

    def create_card(idx):
        stat_row = ft.Row([
            stat_panel("HP", "0", "greenaccent"),
            stat_panel("ATK", "0", "redaccent"),
            stat_panel("DEF", "0", "blueaccent"),
            stat_panel("SPD", "0", "amberaccent"),
            stat_panel("LUK", "0", "purpleaccent")
        ], spacing=4, alignment="center")

        # --- 改善1: 読み込みアクションをまとめたヘッダー ---
        load_header = ft.Row([
            # 画像選択アイコンボタン
            ft.IconButton(
                icon=ft.Icons.ADD_A_PHOTO_ROUNDED,
                icon_color="cyan",
                tooltip="画像からユニットを生成",
                on_click=lambda _: asyncio.create_task(handle_pick(idx))
            ),
            # コード入力フィールド
            ft.TextField(
                label="コードで復元",
                width=200,
                height=30,
                text_size=10,
                hint_text="seed入力...",
                on_submit=lambda e: asyncio.create_task(load_by_code(idx, e.control.value))
            ),
            # クリップボードから貼り付けボタン
            ft.IconButton(
                icon=ft.Icons.ASSIGNMENT_RETURN_ROUNDED,
                icon_color="grey",
                icon_size=18,
                tooltip="クリップボードから貼り付け",
                on_click=lambda e: asyncio.create_task(paste_and_load(idx, e))
            ),
        ], alignment="center", spacing=0)

        # コピーボタンを兼ねたコード表示部
        code_display = ft.TextButton(
            content=ft.Row([
                ft.Text("CODE: ----", size=16, color="grey", font_family="Digital"),
                ft.Icon(ft.Icons.COPY, size=12, color="grey")
            ], alignment="center", spacing=5),
            on_click=lambda e: asyncio.create_task(
                copy_code(e.control.content.controls[0].value.replace("CODE: ", ""))
            )
        )

        return ft.Container(
            visible=True, # --- 改善2: 最初から表示しておく ---
            padding=10, 
            bgcolor=ft.Colors.GREY_900,
            border=ft.Border.all(1, ft.Colors.WHITE24), 
            border_radius=10,
            content=ft.Column([
                ft.Text(f"UNIT {idx+1}", size=12, color="grey", font_family="Dot"),
                load_header, # 読み込み操作を一番上に
                ft.Divider(height=1, color="white10"),
                # 初回はダミー画像を表示
                ft.Image(
                    src="https://flet.dev/img/pages/getting-started/icon.png", 
                    width=140, height=140, fit="cover", border_radius=5,
                    opacity=0.3
                ),
                ft.Text("WAITING...", size=16, weight="bold", font_family="Dot", color="white24"),
                stat_row,
                code_display,
            ], horizontal_alignment="center", spacing=10)
        )


    # 初期化
    players[0]["ui"] = create_card(0)
    players[1]["ui"] = create_card(1)
    battle_button.on_click = run_battle

    page.add(
        ft.Text("フェチバトル: デュエル", size=24, weight="black"),
        ft.Row([
            ft.Column([
                # ft.FilledButton("画像で読み込み", on_click=lambda _: handle_pick(0)),
                ft.FilledButton("画像で読み込み", on_click=lambda _: asyncio.create_task(handle_pick(0))),
                players[0]["ui"]
            ], horizontal_alignment="center"),
            ft.Text("VS", size=20, weight="bold"),
            ft.Column([
                ft.FilledButton("画像で読み込み", on_click=lambda _: asyncio.create_task(handle_pick(1))),
                players[1]["ui"]
            ], horizontal_alignment="center"),
        ], alignment="center", spacing=20),
        ft.Divider(height=20, color="transparent"),
        battle_button,
        ft.Container(content=battle_log, height=180, width=400, bgcolor="black", padding=10, border_radius=5)
    )



if __name__ == "__main__":
    ft.run(main)