import flet as ft
import hashlib
from PIL import Image, ImageStat
import io
import base64

async def main(page: ft.Page):
    page.title = "FETI-BATTLER Scanner"
    page.theme_mode = ft.ThemeMode.DARK
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.AUTO  # 結果が長くなってもいいように

    result_container = ft.Column([], visible=False, horizontal_alignment="center", spacing=10)

    async def handle_pick_files(e):
    # 【重要】with_data=True を追加してメモリ上にバイナリを読み込む
        files = await ft.FilePicker().pick_files(
            file_type=ft.FilePickerFileType.IMAGE,
            allow_multiple=False,
            with_data=True
        )
        
        if not files or len(files) == 0:
            return

        picked_file = files[0]

        # 【重要】ブラウザ環境では open() を使わず picked_file.bytes を直接使う
        img_bytes = picked_file.bytes

        if not img_bytes:
            print("Error: No data received from file picker.")
            return

        # --- 1. ハッシュによる基礎ステータス ---
        seed = hashlib.sha256(img_bytes).hexdigest()
        hp = int(seed[0:4], 16) % 9000 + 1000
        atk = int(seed[4:8], 16) % 4000 + 500

        # try:
        #     with open(picked_file.path, "rb") as f:
        #         img_bytes = f.read()
        # except Exception as err:
        #     print(f"Read Error: {err}")
        #     return

        # # --- 1. ハッシュによる基礎ステータス ---
        # seed = hashlib.sha256(img_bytes).hexdigest()
        # hp = int(seed[0:4], 16) % 9000 + 1000
        # atk = int(seed[4:8], 16) % 4000 + 500
        
        # --- 2. 画像詳細解析 (PIL) ---
        with Image.open(io.BytesIO(img_bytes)) as img:
            width, height = img.size
            total_pixels = width * height
            img_rgb = img.convert("RGB")
            
            # 中央部の平均色を取得（1点より安定）
            crop = img_rgb.crop((width//2-2, height//2-2, width//2+2, height//2+2))
            stat = ImageStat.Stat(crop)
            r, g, b = [int(x) for x in stat.mean]
            
            # --- 3. クスッとする判定ロジック ---
            
            # 素材（マテリアル）属性判定
            if r < 45 and g < 45 and b < 45:
                material = "漆黒のラバー"
                m_color = ft.Colors.GREY_900
            elif r > 180 and g > 140 and b > 120:
                material = "至高のスキン"
                m_color = ft.Colors.ORANGE_200
            elif b > r and b > g:
                material = "伝統のスク水 / 制服"
                m_color = ft.Colors.BLUE_800
            elif r > 200 and g > 200 and b > 200:
                material = "聖なるシルク / ナース"
                m_color = ft.Colors.WHITE
            else:
                material = "未知の魔導素材"
                m_color = ft.Colors.GREY_400

            # 執着心（解像度）ランク
            if total_pixels > 8_000_000: # 800万画素以上
                obsession = "顕微鏡レベルの執着（毛穴まで愛せ）"
            elif total_pixels > 2_000_000:
                obsession = "深淵への入り口"
            else:
                obsession = "淡白な収集癖（まずは画質の確保から）"

            # フェチ純度（RGBの色の差が少ないほど「その色」に特化していると判定）
            diff = abs(r-g) + abs(g-b) + abs(b-r)
            if diff < 30:
                purity = "極（SSS）"
            elif diff < 100:
                purity = "良（A）"
            else:
                purity = "雑念混じり（C）"

            # 表示用変換
            buffered = io.BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode()

        # UI更新
        result_container.controls.clear()
        
        new_img = ft.Image(
            src=f"data:image/png;base64,{img_str}",
            width=300, 
            border_radius=15,
        )
        
        result_container.controls.extend([
            ft.Text("── SCAN COMPLETE ──", size=14, color="grey"),
            new_img,
            ft.Text(f"【 {material} 】", size=28, weight="bold", color=m_color),
            ft.Row([
                ft.Text(f"HP: {hp}", size=24, weight="bold", color="green"),
                ft.Text(f"ATK: {atk}", size=24, weight="bold", color="red"),
            ], alignment="center", spacing=30),
            ft.Divider(height=10, color="white24"),
            ft.Text(f"フェチ純度：{purity}", size=18, weight="bold"),
            ft.Text(f"執着心ランク：{obsession}", size=14, italic=True, color="blue200"),
            ft.Text(f"解析座標の色：R:{r} G:{g} B:{b}", size=12, color="grey"),
        ])
        result_container.visible = True
        page.update()

    page.add(
        ft.SafeArea(
            content=ft.Column([
                ft.Text("FETI-BATTLER", size=45, weight="black", italic=True),
                ft.Text("〜 こだわりの「フェチ」を測定せよ 〜", size=16, color="grey"),
                ft.Container(height=10),
                ft.Button(
                    content=ft.Row([ft.Icon(ft.Icons.CAMERA_ALT), ft.Text("画像を選択してスキャン")], alignment="center"),
                    on_click=handle_pick_files,
                    width=280,
                    height=50,
                ),
                ft.Divider(height=40, color="transparent"),
                result_container
            ], horizontal_alignment="center")
        )
    )

if __name__ == "__main__":
    ft.run(main)